﻿using Crud.Models;
using Crud.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace Crud.Services
{

    public class PassengerServices : IPassengerservices
    {
        IPassengerrepository _context;


        public PassengerServices(IPassengerrepository context)
        {
            this._context = context;
        }

        #region SignUp 
        public SignUp SignUp(SignUp NewUser)
        {
            var TmData = _context.CheckByEmail(NewUser.Email);
            if (TmData != null)
            {
                NewUser.ExistMessage = true;

            }
            else
            {
                _context.SignUp(NewUser);
                var tmpData = _context.CheckByEmail(NewUser.Email);
                NewUser.Id = tmpData.Id;
                NewUser.UserName = tmpData.UserName;
                
            }
            return NewUser;
        }
        #endregion

        #region SignIn 
        public SignUp SignIn(SignUp NewUser)
        {
            var TmData = _context.CheckByEmail(NewUser.Email);
            if (TmData != null)
            {
                if ((TmData.Email == NewUser.Email) && (TmData.Password == NewUser.Password))
                {
                    NewUser.ExistMessage = true;
                    NewUser.Id = TmData.Id;
                    NewUser.UserName = TmData.UserName;
                }
                else if (TmData.Email == NewUser.Email)
                {
                    NewUser.Message = "Invalid Password !";
                }
            }
            else
            {
                NewUser.Message = "Email address not found !";
            }
            return NewUser;
        }
        #endregion

        #region Passenger Details
        public List<Emp> Read(int id)
        {
           return _context.Read(id);

        }
        #endregion

        #region Create Passenger
        public void Create(Emp obj1)
        {
            if (obj1.SpecialSeating == true) { obj1.Requirements += "Special Seating "; };
            if (obj1.SpecialDiet == true) { obj1.Requirements += "Special Diet "; };
            if (obj1.WheelchairAssistance == true) { obj1.Requirements += "Wheelchair assistance "; };
            if (obj1.HandicappedAccomodation == true) { obj1.Requirements += "Handicapped accomodation "; };
            if (obj1.Others == true) { obj1.Requirements += obj1.OtherDetails; };

            _context.Create(obj1);
        }
        #endregion

        #region Update Passenger
        public void Edit(Emp obj1)

        {
            if (obj1.SpecialSeating == true) { obj1.Requirements += "Special Seating "; };
            if (obj1.SpecialDiet == true) { obj1.Requirements += "Special Diet "; };
            if (obj1.WheelchairAssistance == true) { obj1.Requirements += "Wheelchair assistance "; };
            if (obj1.HandicappedAccomodation == true) { obj1.Requirements += "Handicapped accomodation "; };
            if (obj1.Others == true) { obj1.Requirements += obj1.OtherDetails; };

            _context.Edit(obj1);
        }

        #endregion

        #region Delete Passenger
        public void DeleteConfirmed(int PassengerId)
        {
             _context.DeleteConfirmed(PassengerId);    
        }
        #endregion

        #region View Passenger
        public Emp _Details(int PassengerId)
        {
           return _context._Details(PassengerId);
        }
        #endregion

        #region Get Single Passenger Details
        public Emp GetById(int PassengerId)
        {
          return _context.GetById(PassengerId);
        }
        #endregion

        public List<string> Destination()
        {
            return _context.Destination();
        }

        public bool CheckSignUpEmail(string email)
        {
            if (_context.CheckByEmail(email) != null)
            {
                return true;
            }
                return false;
         
        }


    }
}
