﻿using Crud.Models;
using Microsoft.AspNetCore.Mvc;

namespace Crud.Services
{
    public interface IPassengerservices
    {

        SignUp SignUp(SignUp data);


        SignUp SignIn(SignUp data);
        Emp GetById(int PassengerId);
        List<Emp> Read(int id);
      
        void Create(Emp obj1);

        void Edit( Emp passenger);


        void DeleteConfirmed(int PassengerId);

        Emp _Details(int PassengerId);

        List<string> Destination();

        bool CheckSignUpEmail(string email);

    }
}
