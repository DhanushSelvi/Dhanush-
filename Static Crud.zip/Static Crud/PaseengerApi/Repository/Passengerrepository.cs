﻿using Crud.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Data.Common;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Crud.Repository
{

    public class Passengerrepository : IPassengerrepository
    {

        private readonly PassengerContext _dbContext;
        private readonly IConfiguration _configuration;

        public Passengerrepository(PassengerContext dbContext, IConfiguration configuration)
        {
            _configuration = configuration;
            _dbContext = dbContext;
        }

        //public Passengerrepository(IConfiguration configuration)
        //{

        //    _configuration = configuration;
        //}

        #region Dapper connectivity
        public IDbConnection dbContext => new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        #endregion
        
        //User Authentication
        #region SignIn
        public SignUp CheckByEmail(string email)
        {
            using (var connection = dbContext)
            {
                var dataQuery = $"select * from SignUpTable where Email = '{email}'"; 
                var result = connection.Query<SignUp>(dataQuery).FirstOrDefault();
                return result;

            }
        }

        
        #endregion

        #region SignUp
        public void SignUp(SignUp NewUser)
        {
            using (var connection = dbContext)
            {
                var insertQuery = "Insert into SignUpTable(UserName,Email,Password) values(@UserName,@Email,@Password);";
                var data = connection.Execute(insertQuery, NewUser);
            }
        }


        #endregion

        //Passenger Dashboard
        #region Passenger Details
        public List<Emp> Read(int id)
        {

            using (IDbConnection dbConnection = dbContext)
            {
                var Select = $"SELECT * FROM CrudTable where isDelete = 0 AND SignInId = {id} order by Id;";
                var result = dbConnection.Query<Emp>(Select).ToList();
                return result;
            }
        }
        #region Dropdown
        public List<string> Destination()
        {
            using (var connection = dbContext)
            {
                var select = $"Select Destination From DestinationTable;";
                var result=connection.Query<string>(select).ToList();
                return result;
            }
        }
        #endregion
        #endregion


        //Actions on Passenger
        #region Create Passenger 

        public void Create(Emp obj1)
        {
            //_StudentForm.CrudTable.Add(obj1);
            //  _StudentForm.SaveChanges();

            using (var connection = dbContext)
            {
                var insertQuery = "Insert into CrudTable(Id,PassengerName,DateOfBirth,TicketClass,PassengerAddress,Email,Destination,Contactnum,Requirements,SpecialDiet,HandicappedAccomodation,WheelchairAssistance,Others,OtherDetails,SpecialSeating,SignInId ) values (@Id,@PassengerName,@DateOfBirth,@TicketClass,@PassengerAddress,@Email,@Destination,@Contactnum,@Requirements,@SpecialDiet,@HandicappedAccomodation,@WheelchairAssistance,@Others,@OtherDetails,@SpecialSeating,@SignInId );";
                var data = connection.Execute(insertQuery, obj1);
            }

        }
        #endregion

        #region Update Passenger
        public void Edit(Emp passenger)
        {
            using (var connection = dbContext)
            { 
                var PassengerId = passenger.PassengerId;
                var data = $"UPDATE CrudTable SET PassengerName=@PassengerName,DateOfBirth=@DateOfBirth,TicketClass=@TicketClass,PassengerAddress=@PassengerAddress,Email=@Email,Destination=@Destination,Contactnum=@Contactnum,Requirements=@Requirements,SpecialDiet=@SpecialDiet,HandicappedAccomodation=@HandicappedAccomodation,WheelchairAssistance=@WheelchairAssistance,Others=@Others,OtherDetails=@OtherDetails,SpecialSeating=@SpecialSeating where PassengerId={PassengerId}";
                connection.Execute(data, passenger);

            }
        }
        #endregion

        #region Delete Passenger
        public void DeleteConfirmed(int PassengerId)
        {
            using (var connection = dbContext)
            {
              
                var result = $"Update CrudTable Set IsDelete = 1 where PassengerId={PassengerId};";
                connection.Execute(result, PassengerId);

            }

        }
        #endregion

        #region View Passenger

        public Emp _Details(int PassengerId)
        {
            using (var connection = dbContext)
            {

                string dataQuery = $"SELECT * FROM CrudTable WHERE PassengerId={PassengerId};";
                var data = dbContext.Query<Emp>(dataQuery).FirstOrDefault();
                return data;
            }

        }
        #endregion

        #region Get Single Passenger Details
        public Emp GetById(int PassengerId)
        {
            //using (var connection = dbContext)
            //{

            //    string dataQuery = $"SELECT * FROM CrudTable WHERE PassengerId={PassengerId};";
            //    var data = dbContext.Query<Emp>(dataQuery).FirstOrDefault();
            //    return data;
            //}

            var data = _dbContext.CrudTable.SingleOrDefault(p => p.PassengerId == PassengerId);
            return data;



        }
        #endregion


    }
}

