﻿using Crud.Services;
using Crud.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PaseengerApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PassengerApi : ControllerBase
    {
        #region Declaration
        private readonly IPassengerservices _PassengerForm;
        #endregion

        #region Constructor
        public PassengerApi(IPassengerservices PassengerForm)
        {
            _PassengerForm = PassengerForm;

        }
        #endregion

        //User Authentication
        #region SignIn Details
        [HttpPut]
        public IActionResult SignIn(SignUp d)
        {

            SignUp valid = _PassengerForm.SignIn(d);

            return Ok(valid);

        }
        #endregion

        [HttpGet]

        public IActionResult CheckEmail(string email)
        {
            var data = _PassengerForm.CheckSignUpEmail(email);
            return Ok(data);
        }

        #region SignUp Details

        [HttpPut]
        public IActionResult SignUp(SignUp NewUser)
        {
            var result = _PassengerForm.SignUp(NewUser);
            return Ok(result);

        }
        #endregion

        //Passenger Dashboard
        #region Get Passenger Details

        [HttpGet("{id}")]
        public IActionResult Read(int id)
        {
            //return View( _PassengerForm.CrudTable.Where(x=>x.StudentName.StartsWith(search) || search == null).ToList());
            //Emp TempData = null;
            var data = _PassengerForm.Read(id);
            return Ok(data);
        }
        #endregion

        #region Get Single Passenger Details
        [HttpGet("{PassengerId}")]

        public IActionResult GetById(int PassengerId)
        {

            Emp emp =  _PassengerForm.GetById(PassengerId);
            return Ok(emp);
        }
        #endregion

        //Actions on Passenger
        #region Create Passenger
        [HttpPost]

        public IActionResult Create(Emp obj1)
        {
            _PassengerForm.Create(obj1);
            return Ok();
        }
        #endregion

        #region Update Passenger
        [HttpPost]
        public IActionResult Edit(Emp obj)
        {
            _PassengerForm.Edit(obj);
            return Ok();
        }
        #endregion

        #region Delete Passenger
        [HttpGet("{PassengerId}")]

        public IActionResult DeleteConfirmed(int PassengerId) 
        {

           _PassengerForm.DeleteConfirmed(PassengerId);
            return Ok();

         }
        #endregion

        #region DropDown Destination
        [HttpGet]
        public IActionResult Destination()
        {
            List<string> res=_PassengerForm.Destination();

            return Ok(res);
        }
        #endregion
    }
}
