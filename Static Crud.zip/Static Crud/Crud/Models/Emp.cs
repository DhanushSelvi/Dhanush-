﻿//using System.ComponentModel.DataAnnotations;

//namespace Crud.Models
//{
//    public class Emp
//    {
        

//        public int PassengerId { get; set; }
//        public string Id { get; set; }

//        //[Required(ErrorMessage = "Name is required*")]

//        public string PassengerName { get; set; }


//        ////[Required(ErrorMessage = "Age is Required. It cannot be empty*")]
//        //[RegularExpression(@"^(?:[1-9]|[1-9][0-9])$", ErrorMessage = "Enter valid age")]
//        //[Required(ErrorMessage = "Age is required*")]
//        //public string StudentAge { get; set; }

//        //[Required(ErrorMessage = "Address is Required*")]
//        public string PassengerAddress { get; set; }

//        //public string? Subject { get; set; }
//        //public bool Subject1 { get; set; }
//        //public bool Subject2 { get; set; }
//        //public bool Subject3 { get; set; }
//        //public bool Subject4 { get; set; }


//        public string? Requirements { get; set; }


//        public bool SpecialDiet { get; set; }
//        public bool HandicappedAccomodation { get; set; }
//        public bool WheelchairAssistance { get; set; }
//        public bool Others { get; set; }

//        public bool IsDelete {  get; set; }
//        public bool SpecialSeating { get; set; }





//        [Required(ErrorMessage ="Ticket class is required*")]
//        public string TicketClass { get; set; }

//        //[Required(ErrorMessage = "Date of birth is Required*")]
//        public string DateOfBirth { get; set; }

//        //[Required(ErrorMessage = "Email is Required*")]
//        //[RegularExpression(@"^\S+@\S+\.\S+$", ErrorMessage = "Enter valid Email")]

//        public string Email { get; set; }

//        //[Required(ErrorMessage = "Mobile number is Required*")]
//        //[RegularExpression(@"^\d{10}$", ErrorMessage = "Enter valid mobile no")]
//        public string Contactnum { get; set; }

//        //[Required(ErrorMessage = "Course is Required*")]
//        public string Destination { get; set; }
//        public enum destination
//        {
//            Chennai, Coimbatore, Cuddalore , Bangalore
//        }


//    }
//}
