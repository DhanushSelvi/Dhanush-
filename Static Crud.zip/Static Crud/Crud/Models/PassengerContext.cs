﻿//using Microsoft.EntityFrameworkCore;
//using System.Collections.Generic;

//namespace Crud.Models
//{
//    public class PassengerContext : DbContext
//    {
//    public PassengerContext(DbContextOptions options) : base(options)
//    {
//    }
//    public DbSet<Emp> CrudTable { get; set; }

//    }
//}


