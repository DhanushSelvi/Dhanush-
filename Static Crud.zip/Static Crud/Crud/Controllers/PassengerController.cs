﻿using Crud.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Crud.Controllers
{
    public class PassengerController : Controller
    {

        //User Authentication
        #region SignIn Details  
        public IActionResult SignIn()
        {
            if(HttpContext.Session.GetString("SessionTimming") != null)
            {
                HttpContext.Session.Remove("SessionTimming");
                return View();
            }
            else
            {
                return View();
            }
            
        }
        [HttpPost]
        public IActionResult SignIn(SignUp Logindata)
        {
            if (ModelState.IsValid)
            {
               
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7001/api/PassengerApi/SignIn");
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    string data = JsonConvert.SerializeObject(Logindata);
                    StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                    var result = client.PutAsync(client.BaseAddress, content).Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var message = result.Content.ReadAsStringAsync().Result;
                        SignUp? ApiResponse = JsonConvert.DeserializeObject<SignUp>(message);
                        if (ApiResponse.ExistMessage == true)
                        {
                            TempData["Success"] = "Login Successfull !";
                            HttpContext.Session.SetString("SessionTimming","true");
                            HttpContext.Session.SetString("UserName", ApiResponse.UserName);
                            HttpContext.Session.SetInt32("UserId", ApiResponse.Id);
                            return RedirectToAction("Read", "Passenger");
                        }

                        else
                        {
                            
                            ViewBag.msg = ApiResponse.Message;
                        }
                    }
                }
            }
            return View();
        }
        #endregion


        #region SignUp Details
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(SignUp Logindata)
        {
          
            if (ModelState.IsValid)
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7001/api/PassengerApi/SignUp");
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    string data = JsonConvert.SerializeObject(Logindata);
                    StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                    var result = client.PutAsync(client.BaseAddress, content).Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var Existmsg = result.Content.ReadAsStringAsync().Result;
                        SignUp? ApiResponse = JsonConvert.DeserializeObject<SignUp>(Existmsg);
                        if (ApiResponse.ExistMessage== true)
                        {
                            ViewBag.ExistMessage = "Account has already exist !";
                        }
                        else
                        {
                            TempData["Success"] = "Login Successfull !";
                            HttpContext.Session.SetString("SessionTimming", "true");
                            HttpContext.Session.SetString("UserName", ApiResponse.UserName);
                            HttpContext.Session.SetInt32("UserId", ApiResponse.Id);
                            return RedirectToAction("Read", "Passenger");
                        }
                    }
                }
            }
            return View();
        }

        #endregion

        //Passenger Dashboard
        #region Passenger Details
        public IActionResult Read()
        {
            if (HttpContext.Session.GetString("SessionTimming") != null)
            {
                ViewBag.UserName = HttpContext.Session.GetString("UserName");
                var id = HttpContext.Session.GetInt32("UserId");
                TempData["details"] = "True";

                List<Emp> Tmprydata = null;
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri($"https://localhost:7001/api/PassengerApi/Read/{id}");

                    var Records = client.GetAsync(client.BaseAddress);
                    Records.Wait();
                    var read = Records.Result;

                    if (read.IsSuccessStatusCode)
                    {
                        var data = read.Content.ReadAsAsync<List<Emp>>();

                        Tmprydata = (List<Emp>?)data.Result;
                    }
                    return View(Tmprydata);
                }
            }
            else
            {
                return RedirectToAction("SignIn");
            }

        }

        #endregion


        //Actions on Passenger
        #region Create and Update Passenger
        public IActionResult Create(int PassengerId)
        {
            var ListOfItems = DestinationDropDown();
            ViewBag.DropDown = ListOfItems;


            if (HttpContext.Session.GetString("SessionTimming") != null)
            {
                if (PassengerId == 0)
                {
                    return View();
                }
                else
                {
                    ViewBag.msg = "Edit";
                    Emp TempData = null;
                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri($"https://localhost:7001/api/PassengerApi/GetById/{PassengerId}");

                        var Records = client.GetAsync(client.BaseAddress);
                        Records.Wait();
                        var read = Records.Result;

                        if (read.IsSuccessStatusCode)
                        {
                            var data = read.Content.ReadAsAsync<Emp>();

                            TempData = data.Result;
                        }
                        return View(TempData);

                    }

                }
            }
            else
            {
                return RedirectToAction("SignIn");
            }
        }
        [HttpPost]
        public ActionResult Create(Emp obj1)
        {
            var ListOfItems = DestinationDropDown();
            ViewBag.DropDown = ListOfItems;
            if (ModelState.IsValid)
            {
                if (obj1.PassengerId == 0 || obj1.PassengerId==null)
                {
                    using (HttpClient client = new HttpClient())
                    {
                        obj1.SignInId = HttpContext.Session.GetInt32("UserId");
                        client.BaseAddress = new Uri("https://localhost:7001/api/PassengerApi/Create");
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        string data = JsonConvert.SerializeObject(obj1);
                        StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                        var ApiResponse = client.PostAsync(client.BaseAddress, content).Result;
                       
                        if(ApiResponse.IsSuccessStatusCode)
                            {
                            TempData["Message"] = "Passenger Details Added Sucessfully";
                            return RedirectToAction("Read", "Passenger");
                        }
                      
                    }

                }
                else
                {
                    using (HttpClient client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("https://localhost:7001/api/PassengerApi/Edit");
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        string data = JsonConvert.SerializeObject(obj1);
                        StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                        var ApiResponse = client.PostAsync(client.BaseAddress, content).Result;
                      
                        if (ApiResponse.IsSuccessStatusCode)
                        {
                            TempData["Message"] = "Passenger Details Updated Sucessfully";
                            return RedirectToAction("Read", "Passenger");
                        }
                     
                    }

                }

            }
            return View(obj1);
        }


        #endregion


        #region View Passenger Details
        public ActionResult _Details(int PassengerId)

        {
            if (HttpContext.Session.GetString("SessionTimming") != null)
            {
                Emp TempData = null;
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri($"https://localhost:7001/api/PassengerApi/GetById/{PassengerId}");

                    var Records = client.GetAsync(client.BaseAddress);
                    Records.Wait();
                    var read = Records.Result;

                    if (read.IsSuccessStatusCode)
                    {
                        var data = read.Content.ReadAsAsync<Emp>();

                        TempData = data.Result;
                    }
                    return View(TempData);
                }
            }
            else
            {
                return RedirectToAction("SignIn");
            }

        }

        #endregion    


        #region Delete Passenger
        public ActionResult DeleteConfirmed(int PassengerId)

        {
            if (HttpContext.Session.GetString("SessionTimming") != null)
            {

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri($"https://localhost:7001/api/PassengerApi/DeleteConfirmed/{PassengerId}");

                    var Records = client.GetAsync(client.BaseAddress);
                    Records.Wait();
                    var read = Records.Result;

                    if (read.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Read");
                    }
                    return View("DeleteCofirmed");
                }
            }
            else
            {
                return RedirectToAction("SignIn");
            }


        }

        #endregion

        #region Dropdown
        public List<string> DestinationDropDown()
        {
            List<string> ListOfDestination = new List<string>();
            using (var client = new HttpClient())
            {
                var data = client.GetAsync("https://localhost:7001/api/PassengerApi/Destination");
                data.Wait();
                var response = data.Result;
                if (response.IsSuccessStatusCode)
                {
                    ListOfDestination = response.Content.ReadAsAsync<List<string>>().Result;
                    return ListOfDestination;
                }
                else { return ListOfDestination; }
            }
        }
        #endregion
        [HttpGet]
        public IActionResult CheckEmail(string mail)
        {
            bool isExist = false;
            using (var apiconnection = new HttpClient())
            {
                var data = apiconnection.GetAsync($"https://localhost:7001/api/PassengerApi/CheckEmail?email={mail}");
                data.Wait();
                var response = data.Result;
                if (response.IsSuccessStatusCode)
                {
                    isExist = response.Content.ReadAsAsync<bool>().Result;
                    return Json(isExist);
                }
            }
            return Json(isExist);
        }
    
    }

}



