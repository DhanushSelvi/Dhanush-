﻿using Crud.Models;
using System.Data;

namespace Crud.Repository
{


    public interface IPassengerrepository
    {

        List<Emp> Read();
        List<Emp> Read(string obj);
        void Create(Emp obj1);
        void Edit(Emp passenger);

        Emp Edit(int Passenger  );

        //Emp Delete(int StudentId);


        void DeleteConfirmed(int PassengerId);


        Emp Details(int PassengerId);

    }
}
