﻿using Crud.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Data.Common;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Crud.Repository
{

    public class Passengerrepository : IPassengerrepository
    {
        private readonly PassengerContext _PassengerForm;

        private readonly IConfiguration _configuration;


        public Passengerrepository(PassengerContext PassengerForm, IConfiguration configuration)
        {
            _PassengerForm = PassengerForm;
            _configuration = configuration;
        }
        public IDbConnection dbContext => new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));



        #region  Passenger records
        public List<Emp> Read()
        {
            //var result = _StudentForm.CrudTable.ToList();
            //return result;

            using (IDbConnection dbConnection = dbContext)
            {
                var Select = "SELECT* FROM CrudTable where isDelete = 0 order by Id;";
                var result = dbConnection.Query<Emp>(Select).ToList();
                return result;
            }
        }
        #endregion

        #region Search
        public List<Emp> Read(string obj)
        {
            using (IDbConnection dbConnection = dbContext)
            {
                var search = $"SELECT * FROM CrudTable  where isDelete = 0 AND PassengerName LIKE '%{obj}%'";
                var result = dbConnection.Query<Emp>(search).ToList();
                return result;
            }
        }
        #endregion

        #region Create

        public void Create(Emp obj1)
        {
            //_StudentForm.CrudTable.Add(obj1);
            //  _StudentForm.SaveChanges();

            using (var connection = dbContext)
            {
                var insertQuery = "Insert into CrudTable(Id,PassengerName,DateOfBirth,TicketClass,PassengerAddress,Email,Destination,Contactnum,Requirements,SpecialDiet,HandicappedAccomodation,WheelchairAssistance,Others,SpecialSeating) values(@Id,@PassengerName,@DateOfBirth,@TicketClass,@PassengerAddress,@Email,@Destination,@Contactnum,@Requirements,@SpecialDiet,@HandicappedAccomodation,@WheelchairAssistance,@Others,@SpecialSeating);";
                var data = connection.Execute(insertQuery, obj1);
            }

        }
        #endregion

        #region Edit
        public void Edit(Emp passenger)
        {
            using (var connection = dbContext)
            {
                var PassengerId = passenger.PassengerId;
                var data = $"UPDATE CrudTable SET PassengerName=@PassengerName,DateOfBirth=@DateOfBirth,TicketClass=@TicketClass,PassengerAddress=@PassengerAddress,Email=@Email,Destination=@Destination,Contactnum=@Contactnum,Requirements=@Requirements,SpecialDiet=@SpecialDiet,HandicappedAccomodation=@HandicappedAccomodation,WheelchairAssistance=@WheelchairAssistance,Others=@Others,SpecialSeating=@SpecialSeating where PassengerId={PassengerId};";
                connection.Execute(data, passenger);

            }
        }
            public Emp Edit(int PassengerId)
            {
                using (var connection = dbContext)
                {
                    string dataQuery = $"SELECT * FROM CrudTable WHERE PassengerId={PassengerId};";
                    var data = dbContext.Query<Emp>(dataQuery).FirstOrDefault();
                    return data;
                }
            }
        #endregion

        #region Delete

        //public Emp Delete(int StudentId)
        //{
        //    using (var connection = dbContext)
        //    {
                
        //        string dataQuery = $"SELECT * FROM CrudTable WHERE StudentId={StudentId};";
        //        var data = dbContext.Query<Emp>(dataQuery).FirstOrDefault();
        //        return data;
        //    }

        //}

        public void DeleteConfirmed(int PassengerId)
        {
            using (var connection = dbContext)
            {
              
                var result = $"Update CrudTable Set IsDelete = 1 where PassengerId={PassengerId};";
                connection.Execute(result, PassengerId);

            }

        }
        #endregion

        #region Details

        public Emp Details(int PassengerId)
        {
            using (var connection = dbContext)
            {

                string dataQuery = $"SELECT * FROM CrudTable WHERE PassengerId={PassengerId};";
                var data = dbContext.Query<Emp>(dataQuery).FirstOrDefault();
                return data;
            }

        }



    }
    }

#endregion