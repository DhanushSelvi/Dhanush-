﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Passenger_Management_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassengerApi : ControllerBase
    {

    }
}
