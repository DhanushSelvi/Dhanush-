﻿using Crud.Models;
using Crud.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace Crud.Services
{

    public class PassengerServices : IPassengerservices
    {
        IPassengerrepository _context;


        public PassengerServices(IPassengerrepository context)
        {
            this._context = context;
        }

        #region Passengert records
        public List<Emp> Read()
        {
           return _context.Read();

        }
        #endregion

        #region Search
        public List<Emp> Read(string obj)
        {
            return _context.Read(obj);

        }
        #endregion

        #region create
        public void Create(Emp obj1)
        {
            if (obj1.SpecialSeating == true) { obj1.Requirements += "Special Seating "; };
            if (obj1.SpecialDiet == true) { obj1.Requirements += "Special Diet "; };
            if (obj1.WheelchairAssistance == true) { obj1.Requirements += "Wheelchair assistance "; };
            if (obj1.HandicappedAccomodation == true) { obj1.Requirements += "Handicapped accomodation "; };
            if (obj1.Others == true) { obj1.Requirements += " Others "; };

            _context.Create(obj1);
        }
        #endregion

        #region Edit
        public void Edit(Emp obj1)

        {
            if (obj1.SpecialSeating == true) { obj1.Requirements += "Special Seating "; };
            if (obj1.SpecialDiet == true) { obj1.Requirements += "Special Diet "; };
            if (obj1.WheelchairAssistance == true) { obj1.Requirements += "Wheelchair assistance "; };
            if (obj1.HandicappedAccomodation == true) { obj1.Requirements += "Handicapped accomodation "; };
            if (obj1.Others == true) { obj1.Requirements += " Others "; };

            _context.Edit(obj1);
        }
        

       
        public Emp Edit(int PassengerId)
        {
            return _context.Edit(PassengerId);
        }
        #endregion

        #region Delete

        //public Emp Delete(int StudentId)
        //{
        //  return _context.Delete(StudentId);
        //}

        public void DeleteConfirmed(int PassengerId)
        {
             _context.DeleteConfirmed(PassengerId);    
        }
        #endregion

        #region Details
        public Emp Details(int PassengerId)
        {
           return _context.Details(PassengerId);
        }
        #endregion





    }
}
