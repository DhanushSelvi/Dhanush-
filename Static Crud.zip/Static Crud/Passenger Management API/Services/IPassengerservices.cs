﻿using Crud.Models;
using Microsoft.AspNetCore.Mvc;

namespace Crud.Services
{
    public interface IPassengerservices
    {
        List<Emp> Read();
        List<Emp> Read(string obj);
        void Create(Emp obj1);

        void Edit( Emp passenger);

        Emp Edit(int PassengerId);


        //Emp Delete(int StudentId);


        void DeleteConfirmed(int PassengerId);

        Emp Details(int PassengerId);


    }
}
