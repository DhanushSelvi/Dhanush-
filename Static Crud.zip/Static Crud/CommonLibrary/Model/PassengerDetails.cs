﻿using System.ComponentModel.DataAnnotations;


namespace Crud.Models
{
    public class Emp
    {
        
        public int? PassengerId { get; set; }
        public string Id { get; set; }

        public string PassengerName { get; set; }

        public string PassengerAddress { get; set; }

        public string? Requirements { get; set; }

        public bool SpecialDiet { get; set; }
        public bool HandicappedAccomodation { get; set; }
        public bool WheelchairAssistance { get; set; }
        public bool Others { get; set; }

        public string? OtherDetails {  get; set; }
        public bool? IsDelete {  get; set; }
        public bool SpecialSeating { get; set; }

        public string TicketClass { get; set; }

  
        public string? DateOfBirth { get; set; }

        public string Email { get; set; }

       
        public string Contactnum { get; set; }

       
        public string Destination { get; set; }

        public int? SignInId { get; set; }
        //public enum destination
        //{
        //    Chennai, Coimbatore, Cuddalore , Bangalore
        //}


    }
}
